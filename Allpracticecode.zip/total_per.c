#include<stdio.h>
float totper (int,int,int);
int main()
{
int a,b,c;
printf("enter the three subjects marks: ");
scanf("%d %d %d",&a,&b,&c);
float d=totper(a,b,c);
printf("percentage is %f",d);
return 0;
}
float totper (int a,int b,int c)
{
	float t;
	t=a+b+c;
	return (t*100)/300;
}
	
