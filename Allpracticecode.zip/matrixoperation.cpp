#include<iostream>

using namespace std;

class matrix{

	public:

	int row ;
	int col ;
	// int i;
	int **mat;

	
	matrix(int row,int col){
		this->row=row;
		this->col=col;

		mat = new int*[row];

		for(int i=0; i<row;i++){
			mat[i] = new int[row];
		}
	}
	
	void getrow(){
		cout<<"rows:"<<row<<endl;
	}

	void getcol(){
		cout<<"cols:"<<col<<endl;
	}

	void setEle(int i, int j,int ele){
		mat[i][j] = ele;
		// cout<<mat[i][j]<<endl;
	}

	void display(){
		cout<<"contents of matrix"<<endl;
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				cout<<mat[i][j]<<" ";
			}
			cout<<endl;
		}
	}

	matrix operator + (matrix obj){			
		matrix ans(row,col);
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				ans.mat[i][j] = mat[i][j] + obj.mat[i][j];
			}
		}
		return ans;
	}

	matrix operator * (matrix obj){			
		matrix ans(row,col);
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				for(int k=0;k<col;k++){
					ans.mat[i][j] += mat[i][k] * obj.mat[k][j];
				}
			}
		}
		return ans;
	}
};



int main(){

	// matrix m1(2,2),m2(2,2),m3(2,2);
	matrix m1(3,3),m2(3,3),m3(3,3);
	m1.getrow();
	m1.getcol();
	for(int i=0;i<m1.row;i++){
		for(int j=0;j<m1.col;j++){
			m1.setEle(i,j,3);
		}
	}
	m2.getrow();
	m2.getcol();
	for(int i=0;i<m2.row;i++){
		for(int j=0;j<m2.col;j++){
			m2.setEle(i,j,4);
		}
	}

	m1.display();
	m2.display();

	m3=m1+m2;
	cout<<"After Addition ";
	m3.display();

	m3=m1*m2;
	cout<<"After multiplication ";
	m3.display();

	
	return 0;
}
