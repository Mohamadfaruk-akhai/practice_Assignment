#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct library{
	int acnum;				//acess num
	char title[50];
	char author[30];
	int price;
	int flag;		//flag = 1  Issued //flag =  0 not issued
}lib[10]= {			//default entries.
	1, "tit1", "aut1", 200, 1,
	2, "tit2", "aut1", 300, 1,
	3, "tit3", "aut2", 400, 0,
	4, "tit3", "aut3", 150, 0,
	5, "tit5", "aut4", 180, 1
};

int count(){
	int i = 0;
	while (lib[i].acnum)
		i++;
	return i;
}

void display(int i){
	i--;
	printf("\n");
	printf("\nAccession Number : %d", lib[i].acnum);
	printf("\nTitle : %s", lib[i].title);
	printf("\nAuthor : %s", lib[i].author);
	printf("\nPrice : %d", lib[i].price);
	if(lib[i].flag)				//Flag = 1
		printf("\nStatus : Issued");
	else						//Flag = 0
		printf("\nStatus : Not Issued");			
}

void Auth(char *author){
	int i = 0;
	printf("\nBooks of \"%s\" are following : \n", author);
	//checks untill lib.acnum is true, hence here when mylib.an>=4 ->false
	while(lib[i].acnum){
		if (!(strcmp(author, lib[i].author)))
			display(lib[i].acnum);
		i++;
	}
}

void addbook(){
	int next = count();				//count current books
	lib[next].acnum = next + 1;		//add +1 to add another book.

	while (getchar() != '\n');		//not consider enter as value 

	printf("\nEnter the title : ");
	gets(lib[next].title);

	printf("\nEnter the author name : ");
	gets(lib[next].author);

	printf("\nEnter the price : ");
	scanf("%d", &lib[next].price);

	lib[next].flag = 0;			//not issued by default
}

void bookTitle(int acnum){
	acnum--;
	printf("\nTitle of the book : %s\n", lib[acnum].title);
}

void allBook(){
	int i = 0;
	while (lib[i].acnum){
		display(i+1);
		i++;
	}
}

int main(){
	int ans = 1, acnum;
	char auth[30];
	while (ans != 7){
		printf("\n");
		printf("\n1.Add Book Info.");
		printf("\n2.Display Book Info.");
		printf("\n3.List all books of given author.");
		printf("\n4.List the title of specified book.");
		printf("\n5.List the counts of the books in library.");
		printf("\n6.List the books in order of accession number.");
		printf("\n7.Exit.");
		printf("\nEnter you choice : ");
		scanf("%d", &ans);
		switch (ans){
		case 1:
			addbook();
			break;
		case 2:
			printf("\nEnter the accession number of the book : ");
			scanf("%d", &acnum);
			display(acnum);
			break;
		case 3:
			while (getchar() != '\n');
			printf("Enter the name of the author: ");
			gets(auth);
			Auth(auth);
			break;
		case 4:
			printf("\nEnter the accession number of book : ");
			scanf("%d", &acnum);
			bookTitle(acnum);
			break;
		case 5:
			printf("\nTotal Number of books : %d", count());
			break;
		case 6:
			allBook();
			break;
		case 7:
			return 0;
		}
	}
	return 0;
}
